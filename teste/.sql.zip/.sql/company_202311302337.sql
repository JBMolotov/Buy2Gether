INSERT INTO public.company ("cpfCnpj","name",email,"password",address,"fieldOfActivity","isApproved") VALUES
	 ('23.958.780/0001-82','Microsoft','contato@microsoft.com.br','micrO___1999','Avenida Paulist 750','Tecnologia',false),
	 ('99.458.833/0001-68','Padaria São Carlos','contato@padariasaocarlos.br','Pad_SC251','Rua São Carlos 400','Alimentício',true),
	 ('03.449.472/0001-14','Burger King','contato@burgerking.com.br','Whopper10_','Avenida Burger 100','Alimentício',true),
	 ('46.367.663/0001-40','Amazon','contato@amazon.com','_10Amazon__','Rua Amazonia 999','Varejo',true);
