INSERT INTO public.offer ("name","createdOn","updatedAt","deletedAt",price,description,"minimalForFreeDelivery","minimalForConsolidation","totalAmount","isPublic","version","companyId","isDeleted") VALUES
	 ('Bombons do Dia','2023-11-30 23:14:00.656671',NULL,NULL,5,'4 unidades de bombons do dia',10,5,10,true,1,1,false),
	 ('Combo Whopper','2023-11-30 23:16:26.129388',NULL,NULL,15,'Combo Whopper + Batata frita grande + Bebida Grande',20,15,25,true,1,3,false),
	 ('Livros surpresas','2023-11-30 23:19:35.099992','2023-11-30 23:24:29.339',NULL,10,'Um livro surpresa dentre as seguintes opções: Boa noite, Harry Potter e Senhor dos Anéis',5,3,10,true,2,4,false),
	 ('Marmita enche a pança','2023-11-30 23:12:18.408524','2023-11-30 23:25:12.872',NULL,20,'Marmita do dia acompanhada de uma bebida 300mL',8,5,15,true,3,1,false);
