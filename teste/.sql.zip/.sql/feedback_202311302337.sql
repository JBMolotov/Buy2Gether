INSERT INTO public.feedback (description,score,"companyId","offerId","clientId") VALUES
	 ('Marmita muito boa, matou minha fome, compraria de novo',5,1,1,1),
	 ('A marmita veio fria e tinha fios de cabelo na comida',1,1,1,4),
	 ('O livro veio com rasgos em algumas páginas e a capa estava riscada',2,4,4,5);
