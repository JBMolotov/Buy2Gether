INSERT INTO public.client (cpf,"name",email,"password",address,"phoneNumber") VALUES
	 ('027.440.450-05','Pedro Santos','pedro@gmail.com.br','Pedro1234##','Rua São Carlos 20','11912345678'),
	 ('026.450.358-05','Epaminondas','epaminondas@gmail.com','Epaminondas750_','Rua Brasil 10','11912444678'),
	 ('580.401.220-74','George Washington','george_wash@gmail.com','Wash1000_','Rua Estados Unidos 1990','68988472761'),
	 ('625.648.950-00','Tutancâmon','tutucamon@uol.com','Piramide_2','Rua Egito 990','61987513728'),
	 ('026.440.450-05','Antedeguemon','antedeguimon@gmail.com.br','Antedeguemon90##','Rua São Carlos 200','16912344678');
