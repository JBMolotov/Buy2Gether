INSERT INTO public.client_offer_permission (client_id,offer_id) VALUES
	 (1,1),
	 (2,1),
	 (4,1),
	 (3,2),
	 (2,2),
	 (5,4);
