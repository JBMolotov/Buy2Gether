INSERT INTO public.super_admin ("name",email,"password") VALUES
	 ('buy2gether_admin','buy2gether@buy2gether.br','Admin765#');
